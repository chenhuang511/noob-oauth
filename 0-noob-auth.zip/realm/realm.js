const name = 'noob-realm'

module.exports = {active: name}