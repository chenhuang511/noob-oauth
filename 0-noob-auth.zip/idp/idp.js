const user1 = {
    realm: 'noob-realm',
    username: 'user01',
    password: '123456',
    client_roles: ['client1_user', 'client2_user'],
    realm_roles: ['user']
}

const user2 = {
    realm: 'noob-realm',
    username: 'user02',
    password: '123456',
    client_roles: ['client1_admin', 'client2_admin'],
    realm_roles: ['user']
}

let users = [user1, user2]

const authenticate = (realm, username, password) => {
    let f = false
    for (let u of users) {
        f = realm === u.realm && username === u.username && password === u.password
        if (f) break
    }
    return f
}

const register = (realm, username, password) => {
    let realm_roles = ['user']
    let client_roles = ['client1_user']
    users.push({realm, username, password, realm_roles, client_roles})
}

module.exports = {authenticate, register}