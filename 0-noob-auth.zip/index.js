const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')
const cookieParser = require("cookie-parser")
const sessions = require('express-session')

const constants = require('./constants.js')
const realms = require('./realm/realm.js')
const idp = require('./idp/idp.js')
const client = require('./client/client.js')

const app = express()
const PORT = 4000

app.use(sessions({
    secret: "ddSF9jLfmajLF629",
    saveUninitialized: true,
    resave: false
}))

app.use(cookieParser())
app.use(bodyParser.json())
app.use(express.static('./web'))

app.get('/realms/:realm/protocol/openid-connect/auth', ((req, res) => {
    //check cookie for resource owner authenticated session
    if (req.session.noob_session) {

    } else {
        //validate realm
        let realm = req.params['realm']
        if (realm !== realms.active)
            res.status(404).json({error: "Realm does not exist"})

        //validate client
        if (!client.exist(req.query.client_id)) {
            res.sendStatus(400)
            res.end()
            return
        }

        //validate response_type
        let supported = constants.response_types_supported
        if (!supported.includes(req.query.response_type)) {
            res.json({error: "unsupported_response_type"})
            res.end()
            return
        }

        res.sendFile(path.join(__dirname, './web/login.html'))
    }
}))

app.listen(PORT, () => {
    console.log('noob oauth started')
})