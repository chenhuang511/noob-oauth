module.exports = {
    response_types_supported: ['code'],
    grant_types_supported: ['authorization_code', 'refresh_token']
}